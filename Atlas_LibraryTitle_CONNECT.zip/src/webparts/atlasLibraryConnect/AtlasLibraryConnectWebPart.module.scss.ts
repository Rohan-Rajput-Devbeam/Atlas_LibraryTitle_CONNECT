/* tslint:disable */
require("./AtlasLibraryConnectWebPart.module.css");
const styles = {
  atlasLibraryConnect: 'atlasLibraryConnect_f12a561f',
  pageImage: 'pageImage_f12a561f',
  callToAction: 'callToAction_f12a561f',
  arrow: 'arrow_f12a561f'
};

export default styles;
/* tslint:enable */