import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { escape } from '@microsoft/sp-lodash-subset';

import styles from './AtlasLibraryConnectWebPart.module.scss';
import * as strings from 'AtlasLibraryConnectWebPartStrings';

import { CalloutTriggers } from '@pnp/spfx-property-controls/lib/PropertyFieldHeader';
import { PropertyFieldTextWithCallout } from '@pnp/spfx-property-controls/lib/PropertyFieldTextWithCallout';
// import { IFilePickerResult } from '@pnp/spfx-property-controls';
import { PropertyFieldFilePicker, IPropertyFieldFilePickerProps, IFilePickerResult } from "@pnp/spfx-property-controls/lib/PropertyFieldFilePicker";
import { PropertyFieldMessage} from '@pnp/spfx-property-controls/lib/PropertyFieldMessage';
import { PropertyFieldLabelWithCallout } from '@pnp/spfx-property-controls';


export interface IAtlasLibraryConnectWebPartProps {
  description: string;
  PageTitle: string;
  filePickerResult1: any;
}


export default class AtlasLibraryConnectWebPart extends BaseClientSideWebPart<IAtlasLibraryConnectWebPartProps> {

  public render(): void {
    // console.log(this.properties.PageTitle);
    // console.log(this.properties.description);
    // }
    // let pageTitle: string = document.title;
    //---------Get Current Page Title--------------->>
    var flagVar = false;
    const myArray = document.title.split("-");
    let pageTitle = myArray[myArray.length - 1].split(",")[0];
    pageTitle = "Test"

    if (this.properties.PageTitle != pageTitle) {
      flagVar = true;
    }

    if (!this.renderedOnce || flagVar) {
      console.log("First Render")
      // this.properties.PageTitle = pageTitle;

    }


    // console.log("Page Title is---" + pageTitle);
    // if(this.properties.PageTitle = null){
    //   this.properties.PageTitle = pageTitle;

    // }
    // else{

    //   if(this.properties.PageTitle!=pageTitle && this.properties.PageTitle!=null){
    //   console.log(this.properties.PageTitle)
    //   } 
    //   else{
    //     this.properties.PageTitle = pageTitle;
    //     this.properties.description = pageTitle;
    //   }
    // }



    try {
      // Set Image URL received from the file picker component--->
      var myObj1 = (this.properties.filePickerResult1);
      var image1 = myObj1.fileAbsoluteUrl;
    }
    catch (err) {
      // console.error(err);

    }



    if (image1) {

      this.domElement.innerHTML = `
  <head>
           <link rel="preconnect" href="https://fonts.googleapis.com">
       <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
       <link href="https://fonts.googleapis.com/css2?family=Oswald&display=swap" rel="stylesheet">
       </head>
    <div class="${styles.atlasLibraryConnect}">
      <div class="${styles.pageImage}" style="background-image: url(${image1});
      margin-left: 25%;
      height: 10em;
      box-shadow: 0 4px 8px 0 rgb(0 0 0 / 20%), 0 6px 20px 0 rgb(0 0 0 / 19%);
    background-repeat: no-repeat;width:50em;height:10em;
    background-size:cover;
    background-position: center;">
      <div class="${styles.callToAction}">
      ${escape(this.properties.PageTitle)}

      
       </div>
      </div>
    </div>`;



    }

    else {
      this.domElement.innerHTML = `
    <head>
             <link rel="preconnect" href="https://fonts.googleapis.com">
         <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
         <link href="https://fonts.googleapis.com/css2?family=Oswald&display=swap" rel="stylesheet">
         </head>
      <div class="${styles.atlasLibraryConnect}">
        <div class="${styles.pageImage}">
        <div class="${styles.callToAction}">
        ${escape(this.properties.PageTitle)}

        
         </div>
        </div>
      </div>`;



    }






  }


  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('PageTitle', {
                  label: "Page Title",
                  value: this.properties.PageTitle,


                }),
               
                PropertyFieldFilePicker('filePicker1', {
                  context: this.context,
                  filePickerResult: this.properties.filePickerResult1,
                  onPropertyChange: this.onPropertyPaneFieldChanged.bind(this),
                  properties: this.properties,
                  onSave: (e: IFilePickerResult) => { console.log(e); this.properties.filePickerResult1 = e; },
                  onChanged: (e: IFilePickerResult) => { console.log(e); this.properties.filePickerResult1 = e; },
                  key: "filePickerId",
                  buttonLabel: "Select Image(1200w X 150h)",
                  
                  
                 label: "Select Image",
                }),
            
              
           

              ]
            }
          ]
        }
      ]
    };
  }
}
