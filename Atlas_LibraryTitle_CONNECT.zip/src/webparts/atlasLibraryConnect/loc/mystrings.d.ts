declare interface IAtlasLibraryConnectWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'AtlasLibraryConnectWebPartStrings' {
  const strings: IAtlasLibraryConnectWebPartStrings;
  export = strings;
}
