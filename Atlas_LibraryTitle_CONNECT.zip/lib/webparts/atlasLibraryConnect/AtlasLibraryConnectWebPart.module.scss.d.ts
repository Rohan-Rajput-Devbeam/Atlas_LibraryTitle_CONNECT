declare const styles: {
    atlasLibraryConnect: string;
    pageImage: string;
    callToAction: string;
    arrow: string;
};
export default styles;
//# sourceMappingURL=AtlasLibraryConnectWebPart.module.scss.d.ts.map